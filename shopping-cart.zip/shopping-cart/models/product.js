var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var schema = new Schema({
    imagePath : {type: String, required: true},
    coursename: {type: String, required: true},
    professor: {type: String, required: true},
    duration:{type: Number, required: true}

}); 

module.exports = mongoose.model('Product', schema);