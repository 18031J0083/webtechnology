var express = require('express');
var router = express.Router();
var Cart =require('../models/cart');
var mongoose = require('mongoose');
var Product=require('../models/product');
mongoose.connect('mongodb://localhost:27017/shopping', {useNewUrlParser: true});

//var url = 'mongoose://localhost:27017';
//const MongoClinet  =require('mongodb').MongoClient;
//const clinet = new MongoClient(url);
//const dbname = 'shopping';

/* GET home page. */
router.get('/', function(req, res, next) {
  Product.find(function(err,docs){
    var productChunks=[];
    var chunkSize=3;
    for (var i=0;i<docs.length;i+=chunkSize)
    {
      productChunks.push(docs.slice(i,i+chunkSize));
    }
    res.render('shop/index', { title: 'Shopping cart',products: productChunks});
 });
});


router.get('/add-to-cart/:id', function(req, res, next){
  var productId = req.params.id;
  var cart = new Cart(req.session.cart ? req.session.cart : {});

  Product.findById(productId, function(err, product){
    if(err){
        return res.redirect('/');
    }
      cart.add(product, product.id);
      req.session.cart = cart;
      console.log(req.session.cart);
      res.redirect('/');

  });
});

router.get('/reduce/:id', function(req,res,next){
  var productId = req.params.id;
  var cart = new Cart(req.session.cart ? req.session.cart : {});
  cart.reduceByOne(productId);
  req.session.cart = cart;
  res.redirect('/shopping-cart'); 
});

router.get('/increase/:id', function(req,res,next){
  var productId = req.params.id;
  var cart = new Cart(req.session.cart ? req.session.cart : {});
  cart.addByOne(productId);
  req.session.cart = cart;
  res.redirect('/shopping-cart'); 
});

router.get('/remove/:id', function(req,res,next){
  var productId = req.params.id;
  var cart = new Cart(req.session.cart ? req.session.cart : {});
  cart.removeItem(productId);
  req.session.cart = cart;
  res.redirect('/shopping-cart'); 
});


router.get('/shopping-cart', function(req, res, next){
  if(!req.session.cart){
    return res.render('shop/shopping-cart', {products: null});
  }
    var cart = new Cart(req.session.cart);
    res.render('shop/shopping-cart', {products:cart.generateArray(), totalPrice: cart.totalPrice});
  

  });

router.get('/get-data/:id',function(req,res,next){
  var productId=req.params.id;
  var upto=new 
  
  res.redirect('/update/:id');
  });
  
  router.post('/insert',function(req,res,next){
  var products=new Product({
  imagePath:req.body.image,
  title:req.body.title,
  description:req.body.description,
  price:req.body.price
  });
  products.save();
  res.redirect('/shop/adminindex');
  });
  
  router.put('/update/:id',function(req,res){
  const doc=({
  imagePath:req.body.image,
  title:req.body.title,
  description:req.body.description,
  price:req.body.price
  });


  //Product.update({_id:req.params.id},doc,function(err,raw){
  //if(err){
  //res.send(err);
  //}
  //res.send(raw);
  //});

  });
  
  router.get('/delete/:id',function(req,res,next){
  mongoose.model("Product").remove({_id:req.params.id},function(err,delData){
  res.redirect("/shop/adminindex");
  });
  
  });

  router.get('/checkout', function(req,res,next){
  if(!req.session.cart)
  {
    return res.redirect('/shopping-cart');
  }
  res.render('shop/checkout');
});

module.exports = router;
