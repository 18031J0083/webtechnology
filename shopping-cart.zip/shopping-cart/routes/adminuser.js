var express = require('express');
var router = express.Router();
var passport=require('passport');

var csrf = require('csurf');

var csrfProtection =csrf();
router.use(csrfProtection);

router.get('/adminprofile', isLoggedIn, function(req, res, next){
    res.render('Admin/adminprofile');
    });

router.get('/logout', isLoggedIn, function(req, res, next){
    req.logOut();
    res.redirect('/');
});

router.use('/', notLoggedIn, function(req, res, next){
next();
});


router.get('/adminsignup', function(req,res,next)
{
  var messages=req.flash('error');
  res.render('Admin/adminsignup',{csrfToken: req.csrfToken(),messages:messages, hasErrors:messages.length>0});
});


router.post('/adminsignup',passport.authenticate('local.adminsignup',{
  successRedirect:'/Admin/adminprofile',
  failureRedirect:'/Admin/adminsignup',
  failureFlash:true
}));

router.get('/adminsignin', function(req,res,next){
  var messages=req.flash('error');
  res.render('Admin/adminsignin',{csrfToken: req.csrfToken(),messages:messages, hasErrors:messages.length>0});
});

router.post('/adminsignin',passport.authenticate('local.adminsignin', {
  successRedirect:'/shop/adminindex',
  failureRedirect:'/Admin/adminsignin',
  failureFlash:true
}));
 
module.exports = router;

 function isLoggedIn(req,res,next)
 {
     if(req.isAuthenticated())
     {
         return next();
     }
     res.redirect('/');
 }
 function notLoggedIn(req,res,next)
 {
     if(!req.isAuthenticated())
     {
         return next();
     }
     res.redirect('/');
 }